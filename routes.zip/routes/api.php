<?php

use App\Http\Controllers\UserController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\StaffController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\PermissionController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

// Route::get('/user', function (Request $request) {
//     return $request->user();
// })->middleware('auth:sanctum');



    Route::get('/users', [UserController::class, 'users']);

    Route::group(['middleware' => ['web']], function () {
        Route::get('login/facebook', [LoginController::class, 'redirectToFacebook']);

        Route::get('login/facebook/callback', [LoginController::class, 'handleFacebookCallback']);
    });


    Route::get('dashboard', [\App\Http\Controllers\DashboardController::class, 'index']);


    // staff routes

    Route::get('staffs', [StaffController::class, 'index']);
    Route::post('staffs', [StaffController::class, 'store']);
    Route::put('staffs/{id}/activate', [StaffController::class, 'activate']);
    Route::put('staffs/{id}/deactivate', [StaffController::class, 'deactivate']);


    Route::put('staffs/{id}/activate', [StaffController::class, 'activate']);
    Route::put('staffs/{id}/deactivate', [StaffController::class, 'deactivate']);

    //Roles
    Route::get('roles', [RoleController::class, 'index']);
    Route::post('roles', [RoleController::class, 'store']);
    Route::get('roles/{id}', [RoleController::class, 'show']);
    Route::put('roles/{id}', [RoleController::class, 'update']);
    Route::delete('roles/{id}', [RoleController::class, 'destroy']);



    //Permissions
    Route::get('permissions', [PermissionController::class, 'index']);
    Route::post('permissions', [PermissionController::class, 'store']);
    Route::put('permissions/{id}', [PermissionController::class, 'update']);
    Route::delete('permissions/{id}', [PermissionController::class, 'destroy']);






